import java.util.Scanner;
import java.math.*;
import java.util.ArrayList;
import java.util.List;
public class ecc {

    public static List<BigInteger[]> affinepoints(BigInteger a,BigInteger b,BigInteger p)
    {
        List<BigInteger[]> points = new ArrayList<>();

        for(BigInteger i=BigInteger.ZERO;i.compareTo(p)<0;i=i.add(BigInteger.ONE))
        {
            BigInteger x = (i.multiply(i).multiply(i).add(a.multiply(i)).add(b)).mod(p);
            
            for(BigInteger j=BigInteger.ZERO;j.compareTo(p)<0;j=j.add(BigInteger.ONE)) 
            {
                BigInteger y = (j.multiply(j)).mod(p);
                if(x.equals(y))
                {
                    points.add(new BigInteger[]{i,j});
                }

            }

        }
        
        return points;
    }

    public static BigInteger[] scalarMulti(BigInteger a,BigInteger b,BigInteger p,BigInteger na,BigInteger[] g)
    {
        BigInteger[] current = g;
        BigInteger[] result = null;

        for(BigInteger i = BigInteger.ZERO; i.compareTo(na) < 0; i = i.add(BigInteger.ONE))
        {
            result = pointadd(current,result,a,b,p);
        }
        return result;
    }

    public static BigInteger[] pointadd(BigInteger[] curr,BigInteger[] res,BigInteger a,BigInteger b,BigInteger p)
    {
        if(curr==null){return res;}
        if(res==null){return curr;}

        BigInteger x1=curr[0], x2=curr[1];
        BigInteger y1=res[0],y2=res[1];
        BigInteger m ;

        if(x1.equals(y1)&&x1.equals(y2))
        {
            m = x1.multiply(BigInteger.valueOf(3)).add(a).mod(p);
            m = m.multiply(MultiInv(BigInteger.valueOf(2).multiply(y1),p)).mod(p);
        }
        else{
            m = (y2.subtract(y1)).mod(p);
            m = m.multiply(MultiInv(x2.subtract(x1),p)).mod(p);
        }

        BigInteger x3 = m.multiply(m).subtract(x1).subtract(x2).mod(p);
        BigInteger y3 = (m.multiply(x1.subtract(x3)).subtract(y1)).mod(p);
        return new BigInteger[] { x3, y3 };

        
    }

    public static BigInteger MultiInv(BigInteger a, BigInteger b) {
        return a.modInverse(b);
    }

    public static void main(String[] args) {
        
        Scanner obj = new Scanner(System.in);

        BigInteger a = new BigInteger(obj.nextLine());
        BigInteger b = new BigInteger(obj.nextLine());
        BigInteger p = new BigInteger(obj.nextLine());

        List<BigInteger[]> points = affinepoints(a,b,p); 

        for(int i=0;i<points.size();i++)
        {
            System.out.println(i + ": (x: " + points.get(i)[0] + ", y: " + points.get(i)[1] + ")");
        }

        System.out.println("select one point G");
        int gi = obj.nextInt();
        obj.nextLine();

        BigInteger[] g = points.get(gi);

        System.out.println("User A: Enter your private key (nA):");
        BigInteger nA = new BigInteger(obj.nextLine());

        BigInteger[] res = scalarMulti(a,b,p,nA,g);
        System.out.println(res[0]+" "+res[1]);


    }
    
}
