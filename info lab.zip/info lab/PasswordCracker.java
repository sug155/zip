import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class PasswordCracker {
    // Allowed characters in the password
    private static final String ALLOWED_CHARS = "abcdefghijklmnopqrstuvwxyz0123456789!@#$_";

    // Convert bytes to hexadecimal string
    private static String convertBytesToHex(byte[] bytes) {
        StringBuilder hexString = new StringBuilder();
        for (byte b : bytes) {
            hexString.append(String.format("%02X", b));
        }
        return hexString.toString();
    }

    // Check if the password is valid based on allowed characters and length
    private static boolean isPasswordValid(String password, int length) {
        for (char c : password.toCharArray()) {
            if (ALLOWED_CHARS.indexOf(c) == -1) {
                return false;
            }
        }
        return password.length() == length;
    }

    // Recursive function to generate all possible permutations of passwords
    private static void createPermutations(char[] characters, String currentCombination, int targetLength, 
                                           HashMap<String, String> dictionary) {
        try {
            if (currentCombination.length() == targetLength) {
                // Generate MD5 hash of the current permutation
                MessageDigest md = MessageDigest.getInstance("MD5");
                byte[] hash = md.digest(currentCombination.getBytes());

                String hashString = convertBytesToHex(hash);
                dictionary.put(currentCombination, hashString); // Store the permutation and its hash in the dictionary
                return;
            }
            for (char c : characters) {
                createPermutations(characters, currentCombination + c, targetLength, dictionary);
            }
        } catch (NoSuchAlgorithmException e) {
            System.out.println(e);
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter the length of the password:");
        int passwordLength = scanner.nextInt(); // Input password length
        int userChoice;
        HashMap<String, String> userTable = new HashMap<>(); // Store user and hashed password
        HashMap<String, String> dictionary = new HashMap<>(); // Store dictionary of passwords and their hashes

        do {
            System.out.println("1) Enter users and their passwords");
            System.out.println("2) Create dictionary");
            System.out.println("3) Launch attack");
            System.out.println("4) Exit");
            userChoice = scanner.nextInt();
            scanner.nextLine();

            switch (userChoice) {
                case 1: {
                    try {
                        for (int i = 0; i < 10; i++) {
                            System.out.println("Enter username:");
                            String username = scanner.nextLine(); // Input username
                            System.out.println("Enter password (must consist of allowed characters and be of length " + 
                                               passwordLength + "):");
                            String password = scanner.nextLine(); // Input password
                            if (isPasswordValid(password, passwordLength)) {
                                MessageDigest md = MessageDigest.getInstance("MD5");
                                byte[] hash = md.digest(password.getBytes());
                                String passwordHash = convertBytesToHex(hash);
                                userTable.put(username, passwordHash); // Store user and hashed password
                                System.out.println("User added");
                            } else {
                                System.out.println("Invalid password. It must consist of allowed characters and be of length " + 
                                                   passwordLength);
                                System.out.println("User not added");
                                break;
                            }
                        }
                        userTable.forEach((key, value) -> System.out.println("User: " + key + " Hash: " + value));
                    } catch (NoSuchAlgorithmException e) {
                        System.out.println(e);
                    }
                    break;
                }

                case 2: {
                    // Create dictionary of all possible permutations
                    char[] characters = ALLOWED_CHARS.toCharArray();
                    long startTime = System.currentTimeMillis();
                    createPermutations(characters, "", passwordLength, dictionary);
                    long endTime = System.currentTimeMillis();
                    System.out.println("Dictionary created");
                    long timeTaken = endTime - startTime;
                    System.out.println("Time taken: " + timeTaken + " milliseconds");
                    break;
                }

                case 3: {
                    // Launch dictionary attack to find the password for a given user
                    System.out.println("Enter username:");
                    String username = scanner.nextLine();
                    if (userTable.containsKey(username)) {
                        String storedHash = userTable.get(username); // Get the hashed password for the given user
                        String foundPassword = null;
                        // Compare the hashed password with the hashes in the dictionary
                        for (Map.Entry<String, String> entry : dictionary.entrySet()) {
                            if (entry.getValue().equals(storedHash)) {
                                foundPassword = entry.getKey();
                                break; // Exit the loop once the value is found
                            }
                        }
                        if (foundPassword != null) {
                            System.out.println("The password is " + foundPassword);
                        } else {
                            System.out.println("Password not found in dictionary");
                        }
                    } else {
                        System.out.println("Username not present in table");
                    }
                    break;
                }

                case 4: {
                    System.out.println("Exiting");
                    break;
                }
            }
        } while (userChoice != 4);
        scanner.close();
    }
}
