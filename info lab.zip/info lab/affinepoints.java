import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
public class affinepoints {

    public static List<BigInteger[]> KeyGen(BigInteger a,BigInteger b,BigInteger p)
    {
        List<BigInteger[]> points = new ArrayList<>();
        for(BigInteger i=BigInteger.ZERO;i.compareTo(p)<0;i=i.add(BigInteger.ONE))
        {
            BigInteger R = (i.multiply(i).multiply(i).add(a.multiply(i)).add(b)).mod(p);
            for (BigInteger j = BigInteger.ZERO; j.compareTo(p) < 0; j = j.add(BigInteger.ONE)) {
                BigInteger L = (j.multiply(j)).mod(p);
                if (L.equals(R)) {
                    points.add(new BigInteger[] { i, j });
                }

        }
        
    }return points;}

    public static void main(String[] args) {
        
        Scanner obj = new Scanner(System.in);

        BigInteger a = new BigInteger(obj.nextLine());
        BigInteger b = new BigInteger(obj.nextLine());
        BigInteger p = new BigInteger(obj.nextLine());

        List<BigInteger[]> points = KeyGen(a,b,p);

        for (int i = 0; i < points.size(); i++) {
            System.out.println(i + ": (x: " + points.get(i)[0] + ", y: " + points.get(i)[1] + ")");
        }

        System.out.println();

    }
    
}
