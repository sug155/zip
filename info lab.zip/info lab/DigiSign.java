import java.io.IOException;
import java.math.BigInteger;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Scanner;

public class DigiSign {

    public static boolean isPrime(BigInteger p) {
        for (BigInteger i = BigInteger.TWO; i.compareTo(p) < 0; i = i.add(BigInteger.ONE)) {
            if (p.remainder(i).equals(BigInteger.ZERO)) {
                return false;
            }
        }
        return true;
    }

    public static boolean isDivisor(BigInteger p, BigInteger q) {
        BigInteger pminus = p.subtract(BigInteger.ONE);
        return pminus.remainder(q).equals(BigInteger.ZERO);
    }

    public static String hashMessage(String msg) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hashmsg = md.digest(msg.getBytes());
            StringBuilder hexStr = new StringBuilder();
            for (byte b : hashmsg) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) {
                    hexStr.append('0');
                }
                hexStr.append(hex);
            }
            return hexStr.toString();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        return null;
    }

    static BigInteger multiplicativeInverse(BigInteger a, BigInteger m) {
        BigInteger m0 = m, t, q;
        BigInteger x0 = BigInteger.ZERO, x1 = BigInteger.ONE;

        if (m.equals(BigInteger.ZERO)) return null;

        while (a.compareTo(BigInteger.ONE) > 0) {
            q = a.divide(m);
            t = m;
            m = a.mod(m);
            a = t;
            t = x0;
            x0 = x1.subtract(q.multiply(x0));
            x1 = t;
        }

        if (x1.compareTo(BigInteger.ZERO) < 0) {
            x1 = x1.add(m0);
        }

        return x1;
    }

    public static String readmsg(String filepath) throws IOException {
        return new String(Files.readAllBytes(Paths.get(filepath)));
    }

    public static void main(String[] args) throws IOException {
        Scanner obj = new Scanner(System.in);
        System.out.print("enter p: ");
        BigInteger p = new BigInteger(obj.nextLine());

        if (!isPrime(p)) {
            System.out.print("p is not prime");
            return;
        }

        System.out.print("enter q: ");
        BigInteger q = new BigInteger(obj.nextLine());
        if (!isDivisor(p, q)) {
            System.out.print("q is not divisor of p-1");
            return;
        }

        System.out.print("enter h: ");
        BigInteger h = new BigInteger(obj.nextLine());
        if (h.compareTo(BigInteger.ONE) <= 0 || h.compareTo(p) >= 0) {
            System.out.println("Invalid input for h. Please try again.");
            return;
        }

        BigInteger pp = p.subtract(BigInteger.ONE);
        BigInteger qq = pp.divide(q);
        BigInteger g = h.modPow(qq, p);

        System.out.print("enter x: ");
        BigInteger x = new BigInteger(obj.nextLine());
        if (x.compareTo(q) >= 0) {
            System.out.print("invalid x");
            return;
        }

        BigInteger y = g.modPow(x, p);
        System.out.println("x: " + x + ", y: " + y);

        // SIGNATURE GENERATION
        System.out.println("DIGITAL SIGN");
        System.out.print("enter file path: ");
        String filepath = obj.nextLine();
        String msg = readmsg(filepath);

        System.out.print("enter k: ");
        BigInteger k = new BigInteger(obj.nextLine());
        if (k.compareTo(q) >= 0) {
            System.out.print("invalid k");
            return;
        }

        BigInteger r = g.modPow(k, p).mod(q);

        String hashmsg = hashMessage(msg);
        BigInteger hash = new BigInteger(hashmsg, 16);

        BigInteger kinv = multiplicativeInverse(k, q);
        BigInteger s = kinv.multiply(hash.add(x.multiply(r))).mod(q);

        System.out.println("r: " + r);
        System.out.println("s: " + s);

        // KEY VERIFICATION
        System.out.println("KEY VERIFICATION");
        BigInteger sinv = multiplicativeInverse(s, q);

        BigInteger u1 = hash.multiply(sinv).mod(q);
        BigInteger u2 = r.multiply(sinv).mod(q);

        BigInteger a = g.modPow(u1, p);
        BigInteger b = y.modPow(u2, p);
        BigInteger v = a.multiply(b).mod(p).mod(q);

        if (r.equals(v)) {
            System.out.println("verified");
        } else {
            System.out.println("not verified");
        }
    }
}
