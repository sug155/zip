import java.io.*;
import java.math.BigInteger;
import java.net.Socket;
import java.util.Scanner;

public class DiffeMIMB {

    public static void main(String[] args) throws IOException {

        // Connect to the server at localhost on port 8000
        Socket socket = new Socket("localhost", 8001);
        System.out.println("Connected to server");

        // Input/output streams to communicate with the server
        BufferedReader input = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        PrintWriter output = new PrintWriter(socket.getOutputStream(), true);

        Scanner obj = new Scanner(System.in);

        // Receive alpha, q, and ya from the server
        BigInteger alpha = new BigInteger(input.readLine());
        BigInteger q = new BigInteger(input.readLine());
        BigInteger ya = new BigInteger(input.readLine());

        // Input private key xb
        System.out.println("Enter your private key (xb): ");
        BigInteger xb = new BigInteger(obj.nextLine());

        // Ensure xb is less than q
        if (xb.compareTo(q) >= 0) {
            System.out.print("Enter a valid private key less than q");
            return;
        }

        // Calculate yb = alpha^xb mod q
        BigInteger yb = alpha.modPow(xb, q);

        // Send yb to the server
        output.println(yb);

        // Compute shared key k = ya^xb mod q
        BigInteger k = ya.modPow(xb, q);

        // Print the shared key
        System.out.print("Shared key: " + k);

        // Close the socket
        socket.close();
    }
}
