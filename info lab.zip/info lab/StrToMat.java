import java.util.Scanner;

public class StrToMat {
    public static void main(String[] args) {
        Scanner obj = new Scanner(System.in);
        
        // Get the string input from the user
        System.out.println("Enter a string:");
        String a = obj.nextLine();
        
        // Get the number of rows and columns from the user
        System.out.println("Enter the number of rows:");
        int rows = obj.nextInt();
        System.out.println("Enter the number of columns:");
        int cols = obj.nextInt();
        
        char[][] matrix = new char[rows][cols]; // Create a matrix with user-defined rows and columns
        
        // Fill the matrix with characters from the string
        int index = 0;
        int length = a.length();
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                if (index < length) {
                    matrix[i][j] = a.charAt(index); // Assign character to matrix
                    index++;
                } else {
                    matrix[i][j] = ' '; // Fill the remaining spaces with blank
                }
            }
        }
        
        // Print the matrix
        System.out.println("The character matrix is:");
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                System.out.print(matrix[i][j] + " ");
            }
            System.out.println();
        }

        obj.close();
    }
}
