import java.util.Scanner;


class CaesarCipher{

    public String encrypt(String pt,int key){

        String alpha = "abcdefghijklmnopqrstuvwxyz";
        StringBuilder ct = new StringBuilder();
        pt = pt.toLowerCase();
        for(int i=0;i<pt.length();i++)
        {
            char current = pt.charAt(i);
            if(Character.isLetter(current))
            {
                int pos = alpha.indexOf(current);
                int currentct = (key+pos)%26;
                if(currentct<0)
                {
                    currentct=currentct+26;
                }
                char cct = alpha.charAt(currentct);
                ct.append(cct);
            }
            else
            {
                ct.append(current);
            }

        }
        
        return ct.toString();

    }

    public String decrypt(String ct, int key) {

        String alpha = "abcdefghijklmnopqrstuvwxyz";
        ct = ct.toLowerCase();
        StringBuilder pt = new StringBuilder();
        for(int i=0;i<ct.length();i++)
        {
            char current = ct.charAt(i);
            if(Character.isLetter(current))
            {
                int pos = alpha.indexOf(current);
                int currentpt = (pos-key)%26;
                if(currentpt<0)
                {
                    currentpt=currentpt+key; 
                }
                char cpt = alpha.charAt(currentpt);
                pt.append(cpt);
            }
            else{
                pt.append(current);
            }
        }
        
        return pt.toString();
    }
}

public class cc {
    public static void main(String[] args) {
        Scanner obj = new Scanner(System.in);
        System.out.print("enter plain text:");
        String pt = obj.nextLine();
        System.out.print("enter key:");
        int key = obj.nextInt();
        CaesarCipher cc = new CaesarCipher();
        String ct = cc.encrypt(pt, key);
        System.out.println("cipher text:"+ct);
        String dpt = cc.decrypt(ct,key);
        System.out.println("Decrypted text:"+dpt);
    }
}
