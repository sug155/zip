import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.math.BigInteger;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.*;
import java.util.Scanner;

public class DiffeMIMA {

    public static boolean isPrimitiveRoot(BigInteger q,BigInteger a)
    {
        ArrayList<BigInteger> rs = new ArrayList<>();

        BigInteger qminus = q.subtract(BigInteger.ONE);

        //generate residual set
        for(BigInteger i = BigInteger.ONE;i.compareTo(qminus)<=0;i=i.add(BigInteger.ONE))
        {
            rs.add(i);
        }

        ArrayList<BigInteger> result = new ArrayList<>();

        for(BigInteger i = BigInteger.ONE;i.compareTo(qminus)<=0;i=i.add(BigInteger.ONE))
        {
            BigInteger r = a.modPow(i,q);
            result.add(r);
        }

        Collections.sort(result);

        if(rs.equals(result))
        {

            return true;
        }
        else
        {
            return false;
        }
    }

    public static void main(String[] args) throws IOException {
        
        ServerSocket serverSocket = new ServerSocket(8000);
        System.out.println("Waiting for connection");

        // Accept a client connection
        Socket clientSocket = serverSocket.accept();
        System.out.println("Connected to client");

        // Input/output streams to communicate with the client
        BufferedReader input = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
        PrintWriter output = new PrintWriter(clientSocket.getOutputStream(), true);

        Scanner obj = new Scanner(System.in);

        // Input q and alpha from the server admin
        System.out.println("Enter prime number q: ");
        BigInteger q = new BigInteger(obj.nextLine());
        System.out.println("Enter primitive root alpha: ");
        BigInteger alpha = new BigInteger(obj.nextLine());

        // Check if alpha is a primitive root modulo q
        if (!isPrimitiveRoot(q, alpha)) {
            System.out.print("Alpha is not a primitive root modulo q");
            return;
        }

        // Input private key xa from the server admin
        System.out.println("Enter your private key (xa): ");
        BigInteger xa = new BigInteger(obj.nextLine());

        // Ensure xa is less than q
        if (xa.compareTo(q) >= 0) {
            System.out.print("Enter a valid private key less than q");
            return;
        }

        // Calculate ya = alpha^xa mod q
        BigInteger ya = alpha.modPow(xa, q);

        // Send alpha, q, and ya to the client
        output.println(alpha);
        output.println(q);
        output.println(ya);

        // Receive yb from the client
        BigInteger yb = new BigInteger(input.readLine());

        // Compute shared key k = yb^xa mod q
        BigInteger k = yb.modPow(xa, q);

        // Print the shared key
        System.out.print("Shared key: " + k);

        // Close the sockets
        clientSocket.close();
        serverSocket.close();


    }
}