import java.math.BigInteger;
import java.util.Scanner;

public class RSA1 {

    private static final int MAX_CHAR_VALUE = 26; // A-Z + space

    // Check if a number is prime (for small primes, as needed in RSA)
    public static boolean isPrime(int n) {
        if (n <= 1) {
            return false;
        }
        for (int i = 2; i <= Math.sqrt(n); i++) {
            if (n % i == 0) {
                return false;
            }
        }
        return true; // This return statement ensures all paths are covered
    }

    // Method to calculate the modular multiplicative inverse using BigInteger
    public static BigInteger mulinverse(BigInteger e, BigInteger phi) {
        BigInteger a = e;
        BigInteger b = phi;
        BigInteger b0 = b;
        BigInteger t1 = BigInteger.ZERO;
        BigInteger t2 = BigInteger.ONE;
        BigInteger t;
        BigInteger q, r;

        // Special case when b is 1
        if (b.equals(BigInteger.ONE)) {
            return BigInteger.ONE;
        }

        while (a.compareTo(BigInteger.ONE) > 0) {
            q = a.divide(b);
            r = a.mod(b);

            t = t1.subtract(q.multiply(t2));

            a = b;
            b = r;

            t1 = t2;
            t2 = t;
        }

        // Adjust t1 to be positive
        if (t1.compareTo(BigInteger.ZERO) < 0) {
            t1 = t1.add(b0);
        }
        return t1;
    }

    // Method to convert a character to a number (A=0, ..., Z=25, space=26)
    public static int charToNumber(char ch) {
        if (ch == ' ') {
            return MAX_CHAR_VALUE;
        }
        return Character.toUpperCase(ch) - 'A';
    }

    // Method to convert a number back to a character
    public static char numberToChar(int number) {
        if (number == MAX_CHAR_VALUE) {
            return ' ';
        }
        return (char) (number + 'A');
    }

    // Method to encrypt a message using public key (e, n)
    public static String encrypt(String message, BigInteger e, BigInteger n) {
        StringBuilder encryptedMessage = new StringBuilder();
        for (char ch : message.toCharArray()) {
            int m = charToNumber(ch);
            BigInteger mBig = BigInteger.valueOf(m);
            BigInteger c = mBig.modPow(e, n);
            encryptedMessage.append(c.toString()).append(" ");
        }
        return encryptedMessage.toString().trim();
    }

    // Method to decrypt a message using private key (d, n)
    public static String decrypt(String encryptedMessage, BigInteger d, BigInteger n) {
        StringBuilder decryptedMessage = new StringBuilder();
        String[] encryptedValues = encryptedMessage.split(" ");
        for (String value : encryptedValues) {
            if (!value.isEmpty()) {
                try {
                    BigInteger c = new BigInteger(value);
                    BigInteger dm = c.modPow(d, n);
                    decryptedMessage.append(numberToChar(dm.intValue()));
                } catch (NumberFormatException e) {
                    System.out.println("Error: Invalid number format in encrypted message.");
                }
            }
        }
        return decryptedMessage.toString();
    }

    public static void main(String[] args) {
        Scanner obj = new Scanner(System.in);

        System.out.print("Enter values for p and q (both should be prime): ");
        int p = obj.nextInt();
        int q = obj.nextInt();

        if (!isPrime(p)) {
            System.out.println("Error: p is not a prime number.");
            return;
        }

        if (!isPrime(q)) {
            System.out.println("Error: q is not a prime number.");
            return;
        }

        // Calculate n and phi(n)
        BigInteger n = BigInteger.valueOf(p).multiply(BigInteger.valueOf(q));
        BigInteger phi = BigInteger.valueOf(p - 1).multiply(BigInteger.valueOf(q - 1));

        System.out.print("Enter e value (should be coprime with phi): ");
        BigInteger e = obj.nextBigInteger();

        // Check if e is valid
        if (e.compareTo(BigInteger.ONE) <= 0 || e.compareTo(phi) >= 0 || !e.gcd(phi).equals(BigInteger.ONE)) {
            System.out.println("Invalid e. It must be greater than 1, less than " + phi + ", and coprime with " + phi);
            return;
        }

        // Calculate the modular inverse of e mod phi(n)
        BigInteger d = mulinverse(e, phi);

        // Output the public and private keys
        System.out.println("Public Key: (" + e + ", " + n + ")");
        System.out.println("Private Key: (" + d + ", " + n + ")");

        // Encryption
        System.out.print("Enter plain text: ");
        obj.nextLine(); // Consume newline left-over
        String message = obj.nextLine();
        String encryptedMessage = encrypt(message, e, n);
        System.out.println("Cipher text: " + encryptedMessage);

        // Decryption
        String decryptedMessage = decrypt(encryptedMessage, d, n);
        System.out.println("Decrypted message: " + decryptedMessage);
    }
}
