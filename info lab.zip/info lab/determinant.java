import java.util.Scanner;

public class determinant {

    public static int deter(int mat[][],int n)
    {
        
        if(n==1)
        {
            return mat[0][0];
        }

        if(n==2)
        {
            return (mat[0][0]*mat[1][1])-(mat[0][1]*mat[1][0]);
        }

        int d=0;

        for(int i=0;i<n;i++)
        {
            int[][] submat = submatrix(mat,n,i);
            d += Math.pow(-1, i) * mat[0][i] * deter(submat, n - 1); // Changed assignment to accumulation with +=

        }
        
        
        return d;

    }

    public static int[][] submatrix(int mat[][],int n,int i)
    {
        int[][] submat = new int[n-1][n-1];

        for(int j=1;j<n;j++)
        {
            int col=0;
            for(int k=0;k<n;k++)
            {
                if(i==k)
                {
                    continue;
                }
                else
                {
                    submat[j-1][col]=mat[j][k];
                    col++;
                }
            }

        }
        
        return submat;

    }
    public static void main(String[] args) {
        Scanner obj = new Scanner(System.in);
        int n = obj.nextInt();
        int[][] mat = new int[n][n];
        System.out.print("enter numbers:");
        for(int i=0;i<n;i++)
        {
            for(int j=0;j<n;j++)
            {
                mat[i][j]=obj.nextInt();
            }
        }

        int res = deter(mat,n);

        System.out.print(res);


    }

}
