import java.util.Scanner;

public class scalarmul {
    public static void main(String[] args) {
        Scanner obj = new Scanner(System.in);
        System.out.println("enter row and col:");
        int p = obj.nextInt();
        int q = obj.nextInt();
        int[][] mat1 = new int[p][q];

        System.out.print("enter elements:");
        for(int i=0;i<p;i++)
        {
            for(int j=0;j<q;j++)
            {
                mat1[i][j]=obj.nextInt();
            }
        }

        System.out.print("enter elements:");
        int a = obj.nextInt();

        int[][] res = new int[p][q];

        for(int i=0;i<p;i++)
        {
            for(int j=0;j<q;j++)
            {
                res[i][j]=mat1[i][j]*a;
                System.out.print(res[i][j]+" ");
            }
            System.err.println();
        }





    }

}
