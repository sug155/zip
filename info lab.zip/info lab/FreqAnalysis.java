import java.util.Scanner;

class CaesarCipher
{
    public String decrypt(String ct,int key)
    {
        String alpha = "abcdefghijklmnopqrstuvwxyz";
        ct = ct.toLowerCase();
        StringBuilder pt = new StringBuilder();
        for(int i=0;i<ct.length();i++)
        {
            char current = ct.charAt(i);
            if(Character.isLetter(current))
            {
                int pos = alpha.indexOf(current);
                int currentpt = (pos-key)%26;
                if(currentpt<0)
                {
                    currentpt=currentpt+26;
                }
                char cpt = alpha.charAt(currentpt);
                pt.append(cpt);
            }
            else
            {
                pt.append(current);
            }
        }
        return pt.toString();
    }

    public int maxFreq(String ct)
    {
        int i,j,max=0,pos=0;

        for(i=0;i<ct.length();i++)
        {
            char cur = ct.charAt(i);
            int count=0;
            for(j=0;j<ct.length();j++)
            {
                if(cur==(ct.charAt(j)))
                {
                    count++;

                }

            }

            if(count>max)
            {
                max=count;
                pos=i;
            }
        }
        return pos;
    }

}

public class FreqAnalysis {
    public static void main(String[] args) {
        Scanner obj = new Scanner(System.in);
        System.out.print("enter cipher text:");
        String ct=obj.nextLine();
        CaesarCipher cc = new CaesarCipher();
        String freqAlpha = "etaoinshrdlcumwfgypbvkjxqz";
        String alpha = "abcdefghijklmnopqrstuvwxyz";
        int max = cc.maxFreq(ct);
        char a = ct.charAt(max);
        int pos = alpha.indexOf(a);

        for(int i=0;i<freqAlpha.length();i++)
        {
            char freqchar = freqAlpha.charAt(i); 
            int cpos = alpha.indexOf(freqchar);
            int key = (pos-cpos+26)%26;
            if(key<0)
            {
                key=key+26;
            }
            String pt = cc.decrypt(ct, key);
            System.out.println("Plain text when key is"+key+":"+pt);
            System.out.print("Do you want to continue:");
            char reply = obj.next().charAt(0);
            if(reply=='N')
            {
                break;
            }

        }


    }

}
