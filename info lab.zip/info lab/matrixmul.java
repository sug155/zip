import java.util.Scanner;

public class matrixmul {

    public static void main(String[] args) {
        
        Scanner obj = new Scanner(System.in);
        System.out.println("enter row and col:");
        int p = obj.nextInt();
        int q = obj.nextInt();
        int[][] mat1 = new int[p][q];
        System.out.println("enter row and col:");
        int r = obj.nextInt();
        int s = obj.nextInt();
        int[][] mat2 = new int[r][s];

        System.out.print("enter elements:");
        for(int i=0;i<p;i++)
        {
            for(int j=0;j<q;j++)
            {
                mat1[i][j]=obj.nextInt();
            }
        }

        System.out.print("enter elements:");
        for(int i=0;i<r;i++)
        {
            for(int j=0;j<s;j++)
            {
                mat2[i][j]=obj.nextInt();
            }
        }
        int[][] res = new int[p][s];

        if(q!=r)
        {
            System.out.print("not possible");
            return;

        }

        for(int i=0;i<p;i++)
            {
                for(int j=0;j<s;j++)
                {
                    for(int k=0;k<q;k++)
                    {
                        res[i][j]+=mat1[i][k]*mat2[k][j];

                    }
                }
            }


        for(int i=0;i<p;i++)
        {
            for(int j=0;j<s;j++)
            {
                System.out.print(res[i][j]+" ");
            }
            System.out.println();
        }

    }
}
