import java.math.BigInteger;
import java.util.*;
import java.util.Scanner;
public class primitiverootset {


    public static boolean isPrimitiveRoot(BigInteger q,BigInteger a)
    {
        ArrayList<BigInteger> rs = new ArrayList<>();

        BigInteger qminus = q.subtract(BigInteger.ONE);

        //generate residual set
        for(BigInteger i = BigInteger.ONE;i.compareTo(qminus)<=0;i=i.add(BigInteger.ONE))
        {
            rs.add(i);
        }

        ArrayList<BigInteger> result = new ArrayList<>();

        for(BigInteger i = BigInteger.ONE;i.compareTo(qminus)<=0;i=i.add(BigInteger.ONE))
        {
            BigInteger r = a.modPow(i,q);
            result.add(r);
        }

        Collections.sort(result);

        if(rs.equals(result))
        {

            return true;
        }
        else
        {
            return false;
        }


    }

    public static void main(String[] args) {

        Scanner obj = new Scanner(System.in);

        BigInteger q = new BigInteger(obj.nextLine());
        BigInteger qq = q.subtract(BigInteger.ONE);

        for(BigInteger i=BigInteger.ONE;i.compareTo(qq)<=0;i=i.add(BigInteger.ONE))
        {
            if(isPrimitiveRoot(q,i))
            {
                System.out.println(i);
            }
            
        }
        

    }
    
}
