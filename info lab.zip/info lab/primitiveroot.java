import java.math.BigInteger;
import java.util.*;
import java.util.Scanner; 
import java.util.ArrayList;
public class primitiveroot {

    

    public static void main(String[] args) {
        
        Scanner obj = new Scanner(System.in);

        BigInteger q = new BigInteger(obj.nextLine());
        BigInteger a = new BigInteger(obj.nextLine());

        ArrayList<BigInteger> rs = new ArrayList<>();

        BigInteger qminus = q.subtract(BigInteger.ONE);

        //generate residual set
        for(BigInteger i = BigInteger.ONE;i.compareTo(qminus)<=0;i=i.add(BigInteger.ONE))
        {
            rs.add(i);
        }

        ArrayList<BigInteger> result = new ArrayList<>();

        for(BigInteger i = BigInteger.ONE;i.compareTo(qminus)<=0;i=i.add(BigInteger.ONE))
        {
            BigInteger r = a.modPow(i,q);
            result.add(r);
        }

        Collections.sort(result);

        if(rs.equals(result))
        {

            System.out.print("is a primitive root");
        }
        else
        {
            System.out.print("not a primitive root");
        }


    }
    
}
