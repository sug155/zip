import java.util.Scanner;
public class SHA {
    public static void main(String[] args) {
        
        Scanner obj = new Scanner(System.in);

        System.out.print("enter A,B,C,D,E");

        int A = Integer.parseUnsignedInt(obj.nextLine(), 16);
        int B = Integer.parseUnsignedInt(obj.nextLine(), 16);
        int C = Integer.parseUnsignedInt(obj.nextLine(), 16);
        int D = Integer.parseUnsignedInt(obj.nextLine(), 16);
        int E = Integer.parseUnsignedInt(obj.nextLine(), 16);

        //(b and c)or(not b and d)

        int notb = ~B;
        int fn = (B & C)|(notb & D);

        int fnE = fn+E;

        int shiftA = (A << 5)|(A >>> 32-5);

        int shiftAfnE = shiftA + fnE;

        System.out.print("enter msg:");

        String msg = obj.nextLine();

        String submsg;
        if(msg.length()>4)
        {
            submsg=msg.substring(0, 4);
        }
        else{
            submsg=msg;
        }

        int hexvalue=0;

        for(char c:submsg.toCharArray())
        {
            hexvalue = (hexvalue<<8)+(int)c;

        }

        int a = shiftAfnE+hexvalue;

        int addrcon = a+0x5A827999;

        B=A;
        A=addrcon;

        int shiftb = (B<<30)|(B>>>32-30);

        E=D;
        D=C;
        C=shiftb;

        System.out.printf("A: %08X\n", A);
        System.out.printf("B: 0x%08X\n", B);
        System.out.printf("C: 0x%08X\n", C);
        System.out.printf("D: 0x%08X\n", D);
        System.out.printf("E: 0x%08X\n", E);

    }
}
