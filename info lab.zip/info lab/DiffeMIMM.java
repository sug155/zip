import java.io.*;
import java.math.BigInteger;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;

public class DiffeMIMM {

    public static void main(String[] args) throws IOException {
        
        Socket socket = new Socket("localhost", 8000);
        System.out.println("Connected to server a");

        ServerSocket serverSocket = new ServerSocket(8001);
        System.out.println("Waiting for connection");

        Socket clientSocket = serverSocket.accept();
        System.out.println("Connected to client b");

        BufferedReader inputa = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        PrintWriter outputa = new PrintWriter(socket.getOutputStream(), true);
        BufferedReader inputb = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
        PrintWriter outputb = new PrintWriter(clientSocket.getOutputStream(), true);

        Scanner obj = new Scanner(System.in);

        BigInteger alpha = new BigInteger(inputa.readLine());
        BigInteger q = new BigInteger(inputa.readLine());
        BigInteger ya = new BigInteger(inputa.readLine());
        

        System.out.println("Enter your private key (xc): ");
        BigInteger xc = new BigInteger(obj.nextLine());

        // Ensure xb is less than q
        if (xc.compareTo(q) >= 0) {
            System.out.print("Enter a valid private key less than q");
            return;
        }

        BigInteger yc = alpha.modPow(xc, q);

        outputb.println(alpha);
        outputb.println(q);
        outputb.println(yc);
        BigInteger yb = new BigInteger(inputb.readLine());
        outputa.println(yc);

        BigInteger k = ya.modPow(xc, q);
        BigInteger ka = yb.modPow(xc, q);

        System.out.print("Shared key: " + k);
        System.out.print("Shared key: " + ka);

        // Close the sockets
        clientSocket.close();
        serverSocket.close();
    }
    
}
